Weapons and Apparel SFX Library

Distributed under Creative Commons Zero:
https://creativecommons.org/publicdomain/zero/1.0/

Contact Information:
    jan.schupke@gmail.com
    http://www.vehiclemusic.eu
